#!/usr/bin/env python
#encoding:utf-8

import modules.test1 as sss
ttt=sss.aaa()
print(ttt(2,3))
