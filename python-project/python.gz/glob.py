#!/usr/bin/env python
#encoding:utf-8

找出/home/vamei下的所有文件:
import glob
print(glob.glob('/home/vamei/*'))
