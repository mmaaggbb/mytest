#!/usr/bin/env python
#encoding:utf-8


#自定义：模块，在模块目录下必需有__init__.py文件，否则无效
def aaa():
	def bbb(a,b):
		return a+b
	return bbb 
