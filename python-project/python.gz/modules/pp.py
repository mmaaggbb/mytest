import pickle

class Bird(object):
	hava_feather=True
	way_of_reproduction='egg'

